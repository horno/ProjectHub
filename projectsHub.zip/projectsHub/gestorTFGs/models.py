from django.db import models
from django import forms

# Create your models here.

class gestorTFGs(models.Model):
    title = models.CharField(max_length=200)

class PalabrasClave(models.Model):
    nombre = models.CharField(max_length=25)

#class PalabrasClaveForm(forms.ModelForm):
#    class Meta:
#        model = PalabrasClave
#        widgets = {
#            'nombre': forms.TextInput(attrs={'class': 'myfieldclass'}),
#        }

class Titulacion(models.Model):
    nombre = models.CharField(max_length=48)
'''
class TitulacionForm(forms.ModelForm):
    class Meta:
        model = Titulacion
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'myfieldclass'}),
        }
'''
class Propuesta(models.Model):
    ESTADO_CHOICES = [('B','Borrado'), ('E','Esperando'), ('A','Aceptado'), ('C','Completado')]
    estado = models.CharField(choices=ESTADO_CHOICES, max_length=1)
    titol = models.CharField(max_length=25)
    descripcion = models.CharField(max_length=65535)
    objectius = models.CharField(max_length=65535)
    tags = models.ManyToManyField(PalabrasClave, blank=True)
'''
class PropuestaForm(forms.ModelForm):
    class Meta:
        model = Propuesta
        widgets = {
            'ESTADO_CHOICES': forms.TextInput(attrs={'class': 'myfieldclass'}),
            'estado':form.TextInput(attrs={'class': ''})
       }
'''
class Usuario(models.Model):
    ROL_CHOICES = [('A','Alumno'),('P','Profesor'),('ADMIN','Administrador'),('D','Director')]
    rol = models.CharField(choices=ROL_CHOICES, max_length=2)
    login = models.CharField(max_length=16)
    pswd = models.CharField(max_length=25)
    titulacion = models.ManyToManyField(Titulacion)
    suscripcions = models.ManyToManyField(PalabrasClave, blank=True)
    propuestas = models.ManyToManyField(Propuesta, blank=True)

class Funcion(models.Model):
    nombre = models.CharField(max_length=16)
    usuario = models.ForeignKey(Usuario, blank=True, on_delete=models.CASCADE,)
    propuesta = models.ForeignKey(Propuesta, blank=True, on_delete=models.CASCADE)

class Fichero(models.Model):
    fichero = models.BinaryField()
    propuesta = models.ForeignKey(Propuesta, on_delete=models.CASCADE)

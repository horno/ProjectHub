from django.apps import AppConfig


class GestortfgsConfig(AppConfig):
    name = 'gestorTFGs'

from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, 'gestorTFGs/templates/index.html')

def indexProjectes(request):
    return render(request, 'gestorTFGs/templates/indexProjectes.html')

def indexTotsProjectes(request):
    return render(request, 'gestorTFGs/templates/indexTotsProjectes.html')

def login(request):
    return render(request, 'gestorTFGs/templates/login.html')

def register(request):
    return render(request, 'gestorTFGs/templates/register.html')
